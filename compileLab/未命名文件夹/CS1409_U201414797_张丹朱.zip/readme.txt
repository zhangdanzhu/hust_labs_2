工程名称：c--编译器
作者：CS1409张丹朱  U201414797
使用方法： ./parser filename
