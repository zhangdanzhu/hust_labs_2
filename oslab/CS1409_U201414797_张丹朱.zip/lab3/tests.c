#include "stdio.h"

int main()
{
	int sdsadas;
	float kkkkk;
	kkkkk=0;
}
